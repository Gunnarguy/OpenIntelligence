OPENINTELLIGENCE AUDIO STUDY GUIDE TTS PACK
Checked: August 27, 2026

This pack splits the 612-concept full study guide into smaller text files for text-to-speech apps.

Recommended sequence:
1. 00 Orientation and Causal Tour
2. Files 01 through 17 in order
3. 18 Equations and Distinctions
4. 19 Pipeline Recitations

RAPTOR is covered explicitly in file 04, Document Analysis and RAPTOR Lite.

Status language is intentional:
Core means active and load-bearing.
Conditional means active only in particular modes or situations.
Support means evaluation, diagnostics, compatibility, or operations.
Dormant means source exists but it is not an ordinary functioning shipping path.
Future means reserved architecture.
Historical means superseded or misleading if taught as current.
